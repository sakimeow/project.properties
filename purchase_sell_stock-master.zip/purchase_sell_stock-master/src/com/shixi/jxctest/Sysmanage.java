package com.shixi.jxctest;

import android.app.Activity;

public class Sysmanage extends Activity {

}
