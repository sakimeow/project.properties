package com.shixi.domain;

public class StaffAccount {
	public static Integer id = 0;
}
